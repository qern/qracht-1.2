-- phpMyAdmin SQL Dump
-- version 3.4.3.2
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 20 aug 2011 om 11:15
-- Serverversie: 5.5.14
-- PHP-Versie: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qracht`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `kenniskaart`
--

CREATE TABLE IF NOT EXISTS `kenniskaart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profiel_id` int(11) DEFAULT NULL,
  `term` varchar(255) DEFAULT NULL,
  `toegevoegd_op` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `profiel_fotoalbum`
--

CREATE TABLE IF NOT EXISTS `profiel_fotoalbum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profiel_id` int(11) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `caption` text,
  `toegevoegd_op` datetime DEFAULT NULL,
  `toegevoegd_door` varchar(255) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `profiel_fotoalbum_tag`
--

CREATE TABLE IF NOT EXISTS `profiel_fotoalbum_tag` (
  `id` int(11) DEFAULT NULL,
  `profiel_id` int(11) DEFAULT NULL,
  `foto_id` int(11) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `toegevoegd_op` datetime DEFAULT NULL,
  `toegevoegd_door` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `profiel_leuke_collega`
--

CREATE TABLE IF NOT EXISTS `profiel_leuke_collega` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profiel_id` int(11) DEFAULT NULL,
  `collega_id` int(11) DEFAULT NULL,
  `toegevoegd_op` datetime DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `profiel_links`
--

CREATE TABLE IF NOT EXISTS `profiel_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profiel_id` int(11) NOT NULL,
  `url` text NOT NULL,
  `omschrijving` varchar(255) NOT NULL,
  `toegevoegd_op` datetime NOT NULL,
  `toegevoegd_door` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
