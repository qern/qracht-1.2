-- phpMyAdmin SQL Dump
-- version 3.4.3.2
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 20 aug 2011 om 11:14
-- Serverversie: 5.5.14
-- PHP-Versie: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qracht`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `branche`
--

CREATE TABLE IF NOT EXISTS `branche` (
  `id` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `omschrijving` text NOT NULL,
  `actief` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `commentaar`
--

CREATE TABLE IF NOT EXISTS `commentaar` (
  `id` int(11) NOT NULL,
  `relatie_id` int(11) NOT NULL,
  `organisatie_id` int(11) NOT NULL,
  `commentaar` text NOT NULL,
  `geplaatst_door` varchar(255) NOT NULL,
  `geplaatst_op` datetime NOT NULL,
  `actief` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `functie`
--

CREATE TABLE IF NOT EXISTS `functie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titel` varchar(255) NOT NULL,
  `omschrijving` text NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `gebruiker`
--

CREATE TABLE IF NOT EXISTS `gebruiker` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `loginnaam` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL,
  `qwetternaam` varchar(255) NOT NULL,
  `relatie_id` int(11) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `crm_toegang` varchar(255) NOT NULL DEFAULT 'gebruiker',
  `planning_toegang` varchar(255) NOT NULL DEFAULT 'gebruiker',
  `profiel_toegang` varchar(255) NOT NULL DEFAULT 'gebruiker',
  `urentool_toegang` varchar(255) NOT NULL DEFAULT 'gebruiker',
  `laatste_keer_ingelogd` date NOT NULL,
  `aangemaakt_op` date NOT NULL,
  `aangemaakt_door` varchar(255) NOT NULL,
  `versie_id` int(11) NOT NULL,
  `geldig` int(11) NOT NULL,
  `actief` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='table om in te kunnen loggen' AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `organisatie`
--

CREATE TABLE IF NOT EXISTS `organisatie` (
  `id` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `omschrijving` text NOT NULL,
  `branche_id` int(11) NOT NULL,
  `kvk_nummer` int(11) NOT NULL,
  `btw_nummer` int(11) NOT NULL,
  `badres` varchar(255) NOT NULL,
  `bpostcode` varchar(255) NOT NULL,
  `bplaats` varchar(255) NOT NULL,
  `padres` varchar(255) NOT NULL,
  `ppostcode` varchar(255) NOT NULL,
  `pplaats` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `telefoonnummer` varchar(255) NOT NULL,
  `faxnummer` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `contactpersoon_id` int(11) NOT NULL,
  `versie_id` int(11) NOT NULL,
  `actief` int(1) NOT NULL,
  `geldig` int(1) NOT NULL,
  `aangemaakt_op` datetime NOT NULL,
  `aangemaakt_door` varchar(255) NOT NULL,
  `gewijzigd_op` datetime NOT NULL,
  `gewijzigd_door` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `profiel`
--

CREATE TABLE IF NOT EXISTS `profiel` (
  `id` int(11) DEFAULT NULL,
  `gebruiker_id` int(11) DEFAULT NULL,
  `leidinggevende_id` int(11) DEFAULT NULL,
  `profieltekst` text,
  `twitter` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `hyves` varchar(255) NOT NULL,
  `profielfoto_id` int(11) DEFAULT NULL,
  `versie_id` int(11) DEFAULT NULL,
  `actief` tinyint(1) DEFAULT NULL,
  `geldig` tinyint(1) DEFAULT NULL,
  `gewijzigd_op` datetime DEFAULT NULL,
  `gewijzigd_door` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `relaties`
--

CREATE TABLE IF NOT EXISTS `relaties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voornaam` varchar(255) NOT NULL,
  `achternaam` varchar(255) NOT NULL,
  `geboortedatum` date NOT NULL,
  `adres` varchar(255) NOT NULL,
  `postcode` varchar(255) NOT NULL,
  `plaats` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `telefoonnummer` varchar(255) NOT NULL,
  `mobiel` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `geslacht` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `aangemaakt_op` datetime NOT NULL,
  `aangemaakt_door` varchar(255) NOT NULL,
  `versie_id` int(11) NOT NULL,
  `geldig` int(11) NOT NULL,
  `actief` int(11) NOT NULL,
  `status` int(2) NOT NULL,
  `login_id` int(11) NOT NULL DEFAULT '0',
  `is_medewerker` int(1) NOT NULL DEFAULT '0',
  `functie_id` int(11) NOT NULL,
  `soort_relatie_id` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `relatie_organisatie`
--

CREATE TABLE IF NOT EXISTS `relatie_organisatie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relatie_id` int(11) NOT NULL,
  `organisatie_id` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `waarschuw_mij`
--

CREATE TABLE IF NOT EXISTS `waarschuw_mij` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relatie_id` int(11) NOT NULL,
  `organisatie_id` int(11) NOT NULL,
  `gebruiker_id` int(11) NOT NULL,
  `gestart_op` datetime NOT NULL,
  `actief` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
