-- phpMyAdmin SQL Dump
-- version 3.4.3.2
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 20 aug 2011 om 11:16
-- Serverversie: 5.5.14
-- PHP-Versie: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qracht`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `planning_activiteit`
--

CREATE TABLE IF NOT EXISTS `planning_activiteit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organisatie_id` int(11) NOT NULL,
  `werkzaamheden` text NOT NULL,
  `uur_aantal` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `status_datum` date NOT NULL,
  `planning_iteratie_id` int(11) NOT NULL,
  `iteratie_volgorde` int(11) NOT NULL,
  `in_behandeling_door` int(11) NOT NULL DEFAULT '0',
  `acceptatie_door` int(11) NOT NULL,
  `html_detail` text NOT NULL,
  `actief` int(11) NOT NULL DEFAULT '1',
  `geldig` int(11) NOT NULL DEFAULT '1',
  `gewijzigd_op` datetime NOT NULL,
  `gewijzigd_door` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `planning_bestand`
--

CREATE TABLE IF NOT EXISTS `planning_bestand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bestand` varchar(255) NOT NULL,
  `planning_activiteit_id` int(11) NOT NULL,
  `gewijzigd_op` datetime NOT NULL,
  `gewijzigd_door` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `planning_iteratie`
--

CREATE TABLE IF NOT EXISTS `planning_iteratie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `toelichting` text NOT NULL,
  `huidige_iteratie` tinyint(1) NOT NULL,
  `actief` tinyint(1) NOT NULL,
  `geldig` tinyint(1) NOT NULL DEFAULT '1',
  `gewijzigd_op` datetime NOT NULL,
  `gewijzigd_door` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `planning_tag`
--

CREATE TABLE IF NOT EXISTS `planning_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(255) NOT NULL,
  `planning_activiteit_id` int(11) NOT NULL,
  `gewijzigd_op` datetime NOT NULL,
  `gewijzigd_door` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
